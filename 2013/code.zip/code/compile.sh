javac -classpath mallet.jar:mallet-deps.jar src/pathopt/MultitaskPathOpt.java 
mv src/pathopt/*.class bin/pathopt/
